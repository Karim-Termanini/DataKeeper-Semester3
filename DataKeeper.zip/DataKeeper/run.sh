#!/bin/bash
cd "$(dirname "$0")"
echo "Starting DATA KEEPER..."
java -cp out:res main.Main


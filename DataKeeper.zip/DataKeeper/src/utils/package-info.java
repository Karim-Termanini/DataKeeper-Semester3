/**
 * Geteilte Hilfsfunktionen im Spiel: Konstanten, Bild-Utilities, Animationen, Speichern und Pooling.
 * Enthält {@code Constants}, {@code ImageUtils}, {@code AnimationManager}, {@code SaveManager} und {@code EnemyPool}.
 *
 * @since 1.0
 */
package utils;

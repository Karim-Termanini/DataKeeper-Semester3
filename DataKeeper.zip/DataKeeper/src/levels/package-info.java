/**
 * Level-Orchestrierung, Konfiguration und Gegner-Spawn.
 * Stellt {@code LevelManager}, {@code LevelConfig}, {@code SpawnManager} und {@code Portal} bereit.
 *
 * @since 1.0
 */
package levels;

/**
 * Spielfiguren und Akteure der Spielwelt: {@code Player}, {@code Enemy} und {@code Boss}.
 * Enthält die gemeinsame Basisklasse {@code GameCharacter} mit Render- und Update-Lebenszyklus.
 *
 * @since 1.0
 */
package entities;

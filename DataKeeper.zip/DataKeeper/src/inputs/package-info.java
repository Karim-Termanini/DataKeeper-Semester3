/**
 * Tastatur- und Mauseingaben, gemappt auf Spieleraktionen und Menünavigation.
 *
 * @since 1.0
 */
package inputs;

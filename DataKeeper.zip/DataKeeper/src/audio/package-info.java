/**
 * Audiosteuerung für Soundeffekte und Musik, inklusive Fallback-Synthese und Ducking.
 * Stellt das {@code SoundManager}-Singleton und Hilfsfunktionen bereit.
 *
 * @since 1.0
 */
package audio;

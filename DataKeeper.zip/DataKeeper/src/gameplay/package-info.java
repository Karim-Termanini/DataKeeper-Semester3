/**
 * Spielzustand, Timer und übergeordnete Ablaufsteuerung.
 * Stellt {@code GameState} und {@code SurvivalTimer} bereit.
 *
 * @since 1.0
 */
package gameplay;

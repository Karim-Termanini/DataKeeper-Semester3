package gameplay;

public enum GameState {
    MAIN_MENU,
    PLAYING,
    LEVEL_COMPLETE,
    GAME_OVER,
    EPILOGUE,
    VICTORY,
}

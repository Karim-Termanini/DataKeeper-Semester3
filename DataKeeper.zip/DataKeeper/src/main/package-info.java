/**
 * Anwendungs-Bootstrap: Einstiegspunkt, Spiel-Fenster und Haupt-Panel.
 * Beinhaltet Game-Loop, Render-Orchestrierung und Zustandswechsel.
 *
 * @since 1.0
 */
package main;

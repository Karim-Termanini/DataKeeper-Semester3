
			------------------------------	
	
	Laboratory Tileset Revamped LITE (1.0)

	Distributed by ExceptRea (linktr.ee/ExceptRea)

			------------------------------

	If you liked the LITE version consider purchasing PRO version for extended features!

	PRO Version: https://exceptrea.itch.io/laboratory-tileset-revamped-pro

			------------------------------

	License: Creative Commons Attribution-NonCommercial 4.0 International License
	https://creativecommons.org/licenses/by-nc/4.0/

	This LITE version of the Tileset product is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
	You are free to share and adapt the content for any non-commercial purpose, provided you give appropriate credit.

			------------------------------

	Donate: https://ko-fi.com/exceptrea

	You can follow me on my Twitter and Instagram:
	Twitter: www.twitter.com/exceptrea/
	Instagram: www.instagram.com/exceptrea/

	Check out my LoopExchange for NFT's:
	https://loopexchange.art/collection/exceptreaoriginals
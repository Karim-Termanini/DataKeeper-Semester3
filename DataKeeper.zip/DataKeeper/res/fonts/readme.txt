Place an optional UI font here, e.g.:
- DejaVuSans.ttf
- Roboto-Regular.ttf

The game will try to load these for cleaner menu text and Unicode support. Fallbacks: system fonts or Arial.

Optional icons expected here:
- start.png
- story.png
- sfx.png
- music.png
- exit.png
- left.png
- right.png
- star.png

If missing, the menu will fall back to ASCII arrows and simple text.
